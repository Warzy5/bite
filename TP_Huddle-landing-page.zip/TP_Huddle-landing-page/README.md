# TP_Huddle-landing-page
 TP HTML/CSS avec responsive web design

## 1. Prérequis techniques

### 1.1. HTML


### 1.2. CSS


## 2. Objectifs de l'exercice

- [Maquettes Figma](https://www.figma.com/file/fxBN55axe1TIf3CDv3RbUW/huddle-landing-page-with-single-introductory-section?type=design&node-id=0%3A1&mode=design&t=tEtoAHrrs74lW89i-1)
- Intégrer une maquette en mobile first.
- Manipuler les Media Queries (min-width)
- Coder le HTML en respectant la sémantique.

## 3. Brief (à partager avec les élèves)

Votre défi consiste à créer cette page d'accueil à partir des modèles fournis dans le code de départ.

Vous pouvez utiliser les outils que vous préférez pour vous aider à relever ce défi. Donc, si vous avez quelque chose que vous aimeriez pratiquer, n'hésitez pas à essayer.

Vos utilisateurs devraient être en mesure de :

- Voir la mise en page optimale de l'interface en fonction de la taille de l'écran de leur appareil.
- Observer des changements lorsque la souris passe sur les éléments ou lorsqu'ils sont sélectionnés.

Pour commencer, téléchargez le code de départ et lisez le fichier README.md. Il vous donnera plus de détails sur le projet. Vous trouverez les informations sur les couleurs, les polices, etc., dans le fichier `style-guide.md`.



**Pour aller plus loin**

- Utiliser un pré-processeur pour écrire vos styles, comme Sass, Less ou Stylus.
- Entraînez votre œil au détail en essayant de rendre votre solution aussi proche que possible du design d'origine.
- Estimez le temps nécessaire pour réaliser le projet, puis vérifiez si le temps passé correspond à votre estimation. Estimer le temps pour un projet est une compétence souvent négligée mais essentielle pour les développeurs professionnels.


### 4. Ressources pédagogiques
